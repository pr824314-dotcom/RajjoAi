Rajjo AI — পরীক্ষামূলক Android প্রজেক্ট

গুরুত্বপূর্ণ:
- এটি Android Studio/সমর্থিত Android build environment-এ খুলে APK build করার জন্য source project; প্রস্তুত APK নয়।
- এটি পূর্ণ AI chatbot নয়। বর্তমান কোড wake phrase-এর কিছু ভিন্ন রূপ চিনলে “জি, বলুন” বলে।
- Android SpeechRecognizer অনেক ডিভাইসে নেটওয়ার্ক ব্যবহার করে, বিরতিতে থেমে যেতে পারে, এবং সারাক্ষণ background listening-এর জন্য নির্ভরযোগ্য/উপযুক্ত নয়।
- Android 14+ মাইক্রোফোন foreground service শুরু করার ক্ষেত্রে সীমাবদ্ধতা আরোপ করে। অ্যাপের দৃশ্যমান Activity থেকে চালু করতে হবে।
- TECNO/HiOS battery optimization, speech service availability, language recognition support, and notification permission may affect behavior.
- কখনোই অনুমতি বা নিরাপত্তা সতর্কতা জোর করে এড়িয়ে যাবেন না।

Build করার সাধারণ উপায়:
1. Android Studio-তে এই project folder খুলুন।
2. Gradle sync সম্পন্ন হতে দিন।
3. Build > Build APK(s) নির্বাচন করুন।
4. পরীক্ষামূলক APK নিজের ফোনে ইনস্টল করে অনুমতি দিন।
এই কাজের জন্য Android build environment প্রয়োজন; মোবাইল থেকেই build করা সম্ভব হবে কি না তা ব্যবহৃত IDE ও ফোনের ক্ষমতার ওপর নির্ভর করে।
