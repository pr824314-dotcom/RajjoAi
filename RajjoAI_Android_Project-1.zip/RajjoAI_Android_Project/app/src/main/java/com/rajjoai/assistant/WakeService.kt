package com.rajjoai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.content.Context
import android.util.Log
import java.util.Locale

class WakeService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var processing = false
    private var lastRestart = 0L
    private val channelId = "rajjo_ai_listening"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("Rajjo AI চালু আছে")
                .setContentText("‘রাজ্জো এআই’ ডাক শোনার চেষ্টা করছে — বন্ধ করতে অ্যাপ খুলুন")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("Rajjo AI চালু আছে")
                .setContentText("ভয়েস অ্যাসিস্ট্যান্ট চলছে")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        }
        startForeground(7, notification)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { scheduleListen() }
                override fun onResults(results: android.os.Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    onHeard(heard)
                    scheduleListen()
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
            listen()
        }
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) tts?.language = Locale("bn", "BD")
    }

    private fun listen() {
        if (processing || recognizer == null) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) { Log.w("RajjoAI", "startListening failed", e); scheduleListen() }
    }

    private fun scheduleListen() {
        val now = System.currentTimeMillis()
        val delay = maxOf(1200L, 2200L - (now - lastRestart))
        lastRestart = now
        android.os.Handler(mainLooper).postDelayed({ if (!processing) listen() }, delay)
    }

    private fun onHeard(text: String) {
        val q = text.lowercase(Locale.ROOT)
        val wake = q.contains("রাজ্জো") || q.contains("রাজো") || q.contains("rajjo") || q.contains("rajo") || q.contains("রাজ্য এআই")
        if (wake) {
            processing = true
            say("জি, বলুন।")
            android.os.Handler(mainLooper).postDelayed({
                processing = false
                listen()
            }, 2500)
        } else if (processing) {
            say("আপনার কথা শুনেছি। পূর্ণ AI উত্তর দেওয়ার সুবিধা পরের সংস্করণে যুক্ত করতে হবে।")
            processing = false
        }
    }

    private fun say(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rajjo_reply")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Rajjo AI microphone", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Rajjo AI voice assistant foreground service"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
