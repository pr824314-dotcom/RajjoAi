package com.rajjoai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 21
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
        }
        val title = TextView(this).apply {
            text = "Rajjo AI\n\n‘রাজ্জো এআই’ বলে ডাকলে সাড়া দেওয়ার পরীক্ষামূলক সহকারী"
            textSize = 22f
        }
        val info = TextView(this).apply {
            text = "\nচালু করলে একটি স্থায়ী নোটিফিকেশন দেখা যাবে। মাইক্রোফোন অনুমতি আবশ্যক। এটি পরীক্ষামূলক সংস্করণ; সব ফোনে বা স্ক্রিন লক অবস্থায় নির্ভরযোগ্যভাবে কাজের নিশ্চয়তা নেই।"
            textSize = 16f
        }
        val start = Button(this).apply { text = "Rajjo AI চালু করো" }
        val stop = Button(this).apply { text = "শোনা বন্ধ করো" }
        layout.addView(title); layout.addView(info); layout.addView(start); layout.addView(stop)
        setContentView(layout)

        start.setOnClickListener {
            val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), requestCode)
            else startAssistant()
        }
        stop.setOnClickListener { stopService(Intent(this, WakeService::class.java)); Toast.makeText(this, "Rajjo AI বন্ধ করা হয়েছে", Toast.LENGTH_SHORT).show() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startAssistant()
        else Toast.makeText(this, "মাইক্রোফোন ও প্রয়োজনীয় অনুমতি ছাড়া Rajjo AI শুনতে পারবে না।", Toast.LENGTH_LONG).show()
    }

    private fun startAssistant() {
        try {
            val intent = Intent(this, WakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "Rajjo AI চালু করার অনুরোধ পাঠানো হয়েছে", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "চালু করা যায়নি: " + (e.message ?: "অজানা সমস্যা"), Toast.LENGTH_LONG).show()
        }
    }
}
